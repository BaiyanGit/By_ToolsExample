﻿namespace _3rdBy.MetaFramework.FSM
{
    using System;

    public class StateSwitchCondition
    {
        public readonly Func<bool> predicate;

        public readonly string sourceStateName;

        public readonly string targetStateName;

        public StateSwitchCondition(Func<bool> predicate, string sourceStateName, string targetStateName)
        {
            this.predicate = predicate;
            this.sourceStateName = sourceStateName;
            this.targetStateName = targetStateName;
        }
    }
}