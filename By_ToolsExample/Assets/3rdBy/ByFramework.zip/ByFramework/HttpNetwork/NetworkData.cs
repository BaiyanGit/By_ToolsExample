﻿namespace _3rdBy.MetaFramework.HttpNetwork
{
    using System;

    [Serializable]
    public class RequestDataStruct
    {
    }

    [Serializable]
    public class ResponseDataStruct
    {
        public int code;
        public string msg;
    }


    // [Serializable]
    // public class ResponseDataStruct
    // {
    //     public bool success;
    //     public int code;
    //     public string message;
    // }
}