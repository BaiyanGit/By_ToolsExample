namespace Demos.示例_快捷键切换应用.Scripts.KeyPadAPI
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using UnityEngine;
    using UnityEngine.EventSystems;
    using UnityEngine.UI;
    using Debug = UnityEngine.Debug;

    /// <summary>
    /// UGUI 版本窗口切换控制器。
    /// 
    /// 使用方式：
    /// 1. 可以挂到任意 GameObject 上。
    /// 2. 勾选 autoCreateUi 后，会在运行时自动创建 Canvas / Panel / Button / Dropdown / ScrollView。
    /// 3. 也可以通过 Editor 菜单一键生成完整 UGUI 场景。
    /// 
    /// 本类不影响 OnGUI 版本 WindowController，两套 UI 可以同时保留。
    /// </summary>
    public class WindowControllerUGUI : MonoBehaviour
    {
        [Header("是否在运行时自动创建 UGUI 界面")] [SerializeField]
        private bool autoCreateUi = true;

        [Header("目标 Canvas，为空时自动创建")] [SerializeField]
        private Canvas targetCanvas;

        [Header("UGUI 根面板")] [SerializeField] private RectTransform rootPanel;

        [Header("进程列表内容父节点")] [SerializeField] private RectTransform processContent;

        [Header("状态文本")] [SerializeField] private Text statusText;

        [Header("快捷键第一个按键下拉框")] [SerializeField]
        private Dropdown dropdownKey1;

        [Header("快捷键第二个按键下拉框")] [SerializeField]
        private Dropdown dropdownKey2;

        [Header("搜索进程输入框")] [SerializeField] private InputField inputSearch;

        [Header("是否只显示有主窗口句柄的进程")] [SerializeField]
        private Toggle toggleOnlyWindow;

        [Header("隐藏按钮是否完全隐藏窗口，否则执行最小化")] [SerializeField]
        private Toggle toggleUseHide;

        [Header("UI 缩放滑条")] [SerializeField] private Slider sliderUiScale;

        [Header("UI 缩放数值文本")] [SerializeField] private Text textUiScale;

        [Header("刷新进程列表按钮")] [SerializeField] private Button btnRefresh;

        [Header("隐藏/显示主面板按钮")] [SerializeField]
        private Button btnTogglePanel;

        [Header("最小化当前 Unity 窗口按钮")] [SerializeField]
        private Button btnMinimize;

        [Header("最大化当前 Unity 窗口按钮")] [SerializeField]
        private Button btnMaximize;

        [Header("还原当前 Unity 窗口按钮")] [SerializeField]
        private Button btnRestore;

        [Header("关闭当前应用按钮")] [SerializeField] private Button btnClose;

        [Header("启动时是否自动刷新一次进程列表")] [SerializeField]
        private bool refreshProcessListOnStart = true;

        [Header("当前 UI 缩放")] [SerializeField] private float uiScale = 1f;

        [Header("快捷键第一个按键索引")] [SerializeField]
        private int hotkeyIndex1 = 1;

        [Header("快捷键第二个按键索引，0 表示不设置")] [SerializeField]
        private int hotkeyIndex2 = 17;

        private const float MinUiScale = 0.75f;
        private const float MaxUiScale = 1.75f;

        private readonly HashSet<int> _pressedKeys = new();
        private readonly List<ProcessInfo> _processInfos = new();
        private readonly List<GameObject> _spawnedRows = new();

        private KeyboardHook _windowsKeyboardHook;
        private bool _shortcutTriggered;
        private bool _panelVisible = true;
        private int _hotkeyTriggerCount;
        private string _statusText = "未启动";

        private Font _defaultFont;

        private void Awake()
        {
            Application.runInBackground = true;
            uiScale                     = Mathf.Clamp(uiScale, MinUiScale, MaxUiScale);

            if (autoCreateUi)
            {
                BuildDefaultUGUI();
            }

            BindEvents();
            InitializeKeyDropdowns();
            ApplyUiScale();
            SetStatus("UGUI 工具已启动。");

            if (refreshProcessListOnStart)
            {
                RefreshProcessList();
            }
        }

        private void OnEnable()
        {
            InstallKeyboardHook();
        }

        private void OnDisable()
        {
            UninstallKeyboardHook();
        }

        private void OnDestroy()
        {
            UnbindEvents();
            UninstallKeyboardHook();
        }

        private void OnApplicationQuit()
        {
            UninstallKeyboardHook();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F2))
            {
                TogglePanelVisible();
            }
        }

        /// <summary>
        /// 自动创建完整 UGUI 界面。
        /// </summary>
        private void BuildDefaultUGUI()
        {
            _defaultFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

            EnsureCanvas();
            EnsureEventSystem();

            rootPanel           = CreatePanel("HotkeySwitchApp_UGUI_Panel", targetCanvas.transform as RectTransform);
            rootPanel.anchorMin = new Vector2(0.02f, 0.05f);
            rootPanel.anchorMax = new Vector2(0.98f, 0.95f);
            rootPanel.offsetMin = Vector2.zero;
            rootPanel.offsetMax = Vector2.zero;

            var vertical = rootPanel.gameObject.AddComponent<VerticalLayoutGroup>();
            vertical.padding                = new RectOffset(10, 10, 8, 10);
            vertical.spacing                = 6;
            vertical.childControlHeight     = false;
            vertical.childControlWidth      = true;
            vertical.childForceExpandHeight = false;
            vertical.childForceExpandWidth  = true;

            rootPanel.gameObject.AddComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.Unconstrained;

            BuildHeader(rootPanel);
            BuildHotkeyRow(rootPanel);
            BuildProcessToolbar(rootPanel);
            BuildProcessScrollView(rootPanel);
        }

        private void EnsureCanvas()
        {
            if (targetCanvas != null)
            {
                return;
            }

            var canvasObject = new GameObject("HotkeySwitchApp_Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            targetCanvas              = canvasObject.GetComponent<Canvas>();
            targetCanvas.renderMode   = RenderMode.ScreenSpaceOverlay;
            targetCanvas.sortingOrder = 1000;

            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720);
            scaler.matchWidthOrHeight  = 0.5f;
        }

        private static void EnsureEventSystem()
        {
            if (FindObjectOfType<EventSystem>() != null)
            {
                return;
            }

            var eventSystemObject = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            eventSystemObject.transform.SetAsLastSibling();
        }

        private void BuildHeader(RectTransform parent)
        {
            var header = CreateHorizontalGroup("Header", parent, 42);

            var title = CreateText("Title", "快捷键切换应用 - UGUI", header, 22, FontStyle.Bold, TextAnchor.MiddleLeft);
            AddLayout(title.gameObject, 1, -1, -1);

            btnMinimize    = CreateButton("BtnMinimize", "最小化", header, 80, 32);
            btnMaximize    = CreateButton("BtnMaximize", "最大化", header, 80, 32);
            btnRestore     = CreateButton("BtnRestore", "还原", header, 70, 32);
            btnTogglePanel = CreateButton("BtnTogglePanel", "隐藏面板", header, 90, 32);
            btnClose       = CreateButton("BtnClose", "关闭", header, 60, 32);

            statusText = CreateText("StatusText", "状态：", parent, 14, FontStyle.Normal, TextAnchor.MiddleLeft);
            AddLayout(statusText.gameObject, 1, -1, 26);
        }

        private void BuildHotkeyRow(RectTransform parent)
        {
            var row = CreateHorizontalGroup("HotkeyAndScaleRow", parent, 40);

            CreateText("LabelKey1", "快捷键1", row, 14, FontStyle.Bold, TextAnchor.MiddleLeft);
            dropdownKey1 = CreateDropdown("DropdownKey1", row, 160, 30);

            CreateText("LabelKey2", "快捷键2", row, 14, FontStyle.Bold, TextAnchor.MiddleLeft);
            dropdownKey2 = CreateDropdown("DropdownKey2", row, 160, 30);

            CreateText("LabelScale", "UI缩放", row, 14, FontStyle.Bold, TextAnchor.MiddleLeft);
            sliderUiScale          = CreateSlider("SliderUiScale", row, 160, 30);
            sliderUiScale.minValue = MinUiScale;
            sliderUiScale.maxValue = MaxUiScale;
            sliderUiScale.value    = uiScale;

            textUiScale = CreateText("TextScaleValue", uiScale.ToString("0.00"), row, 14, FontStyle.Normal, TextAnchor.MiddleLeft);
            AddLayout(textUiScale.gameObject, 0, 50, 28);

            toggleUseHide = CreateToggle("ToggleUseHide", "隐藏按钮完全隐藏", row, 150, 30);
        }

        private void BuildProcessToolbar(RectTransform parent)
        {
            var row = CreateHorizontalGroup("ProcessToolbar", parent, 40);

            toggleOnlyWindow      = CreateToggle("ToggleOnlyWindow", "只显示有窗口进程", row, 160, 30);
            toggleOnlyWindow.isOn = true;

            CreateText("LabelSearch", "搜索", row, 14, FontStyle.Bold, TextAnchor.MiddleLeft);
            inputSearch = CreateInputField("InputSearch", row, 220, 30);

            btnRefresh = CreateButton("BtnRefresh", "刷新进程列表", row, 120, 32);

            var copySearchButton = CreateButton("BtnCopySearch", "复制搜索", row, 90, 32);
            copySearchButton.onClick.AddListener(() =>
            {
                GUIUtility.systemCopyBuffer = inputSearch != null ? inputSearch.text : string.Empty;
                SetStatus("已复制搜索内容：" + GUIUtility.systemCopyBuffer);
            });

            var clearSearchButton = CreateButton("BtnClearSearch", "清空搜索", row, 90, 32);
            clearSearchButton.onClick.AddListener(() =>
            {
                if (inputSearch != null)
                {
                    inputSearch.text = string.Empty;
                }

                RefreshProcessListView();
            });
        }

        private void BuildProcessScrollView(RectTransform parent)
        {
            var scrollObject = new GameObject("ProcessScrollView", typeof(RectTransform), typeof(Image), typeof(ScrollRect));
            scrollObject.transform.SetParent(parent, false);
            AddLayout(scrollObject, 1, -1, 0);

            var scrollRectTransform = scrollObject.GetComponent<RectTransform>();
            var scrollImage         = scrollObject.GetComponent<Image>();
            scrollImage.color = new Color(0f, 0f, 0f, 0.28f);

            var scrollRect = scrollObject.GetComponent<ScrollRect>();
            scrollRect.horizontal = false;
            scrollRect.vertical   = true;

            var viewport = CreatePanel("Viewport", scrollRectTransform);
            viewport.anchorMin = Vector2.zero;
            viewport.anchorMax = Vector2.one;
            viewport.offsetMin = new Vector2(4, 4);
            viewport.offsetMax = new Vector2(-4, -4);

            var mask = viewport.gameObject.AddComponent<Mask>();
            mask.showMaskGraphic = false;

            var viewportImage = viewport.GetComponent<Image>();
            viewportImage.color = new Color(1f, 1f, 1f, 0.04f);

            processContent = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter)).GetComponent<RectTransform>();
            processContent.SetParent(viewport, false);
            processContent.anchorMin = new Vector2(0, 1);
            processContent.anchorMax = new Vector2(1, 1);
            processContent.pivot     = new Vector2(0.5f, 1);
            processContent.offsetMin = Vector2.zero;
            processContent.offsetMax = Vector2.zero;

            var contentLayout = processContent.GetComponent<VerticalLayoutGroup>();
            contentLayout.spacing                = 3;
            contentLayout.padding                = new RectOffset(4, 4, 4, 4);
            contentLayout.childControlWidth      = true;
            contentLayout.childForceExpandWidth  = true;
            contentLayout.childControlHeight     = false;
            contentLayout.childForceExpandHeight = false;

            var fitter = processContent.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scrollRect.viewport = viewport;
            scrollRect.content  = processContent;

            CreateProcessHeader(processContent);
        }

        private void CreateProcessHeader(RectTransform parent)
        {
            var row = CreateProcessRowBase("HeaderRow", parent, new Color(0.10f, 0.10f, 0.10f, 0.85f));
            CreateProcessCell("序号", row, 45, FontStyle.Bold);
            CreateProcessCell("PID", row, 70, FontStyle.Bold);
            CreateProcessCell("主窗口句柄", row, 130, FontStyle.Bold);
            CreateProcessCell("进程名", row, 260, FontStyle.Bold);
            CreateProcessCell("操作", row, 420, FontStyle.Bold);
        }

        private void BindEvents()
        {
            if (btnRefresh != null)
            {
                btnRefresh.onClick.AddListener(RefreshProcessList);
            }

            if (btnTogglePanel != null)
            {
                btnTogglePanel.onClick.AddListener(TogglePanelVisible);
            }

            if (btnMinimize != null)
            {
                btnMinimize.onClick.AddListener(WindowAPI.WindowMinimize);
            }

            if (btnMaximize != null)
            {
                btnMaximize.onClick.AddListener(WindowAPI.WindowMaximize);
            }

            if (btnRestore != null)
            {
                btnRestore.onClick.AddListener(WindowAPI.WindowRestore);
            }

            if (btnClose != null)
            {
                btnClose.onClick.AddListener(WindowAPI.WindowClose);
            }

            if (dropdownKey1 != null)
            {
                dropdownKey1.onValueChanged.AddListener(OnDropdownKey1Changed);
            }

            if (dropdownKey2 != null)
            {
                dropdownKey2.onValueChanged.AddListener(OnDropdownKey2Changed);
            }

            if (sliderUiScale != null)
            {
                sliderUiScale.onValueChanged.AddListener(OnScaleChanged);
            }

            if (inputSearch != null)
            {
                inputSearch.onValueChanged.AddListener(_ => RefreshProcessListView());
            }

            if (toggleOnlyWindow != null)
            {
                toggleOnlyWindow.onValueChanged.AddListener(_ => RefreshProcessListView());
            }
        }

        private void UnbindEvents()
        {
            if (btnRefresh != null) btnRefresh.onClick.RemoveListener(RefreshProcessList);
            if (btnTogglePanel != null) btnTogglePanel.onClick.RemoveListener(TogglePanelVisible);
            if (btnMinimize != null) btnMinimize.onClick.RemoveListener(WindowAPI.WindowMinimize);
            if (btnMaximize != null) btnMaximize.onClick.RemoveListener(WindowAPI.WindowMaximize);
            if (btnRestore != null) btnRestore.onClick.RemoveListener(WindowAPI.WindowRestore);
            if (btnClose != null) btnClose.onClick.RemoveListener(WindowAPI.WindowClose);

            if (dropdownKey1 != null) dropdownKey1.onValueChanged.RemoveListener(OnDropdownKey1Changed);
            if (dropdownKey2 != null) dropdownKey2.onValueChanged.RemoveListener(OnDropdownKey2Changed);
            if (sliderUiScale != null) sliderUiScale.onValueChanged.RemoveListener(OnScaleChanged);
        }

        private void InitializeKeyDropdowns()
        {
            FillKeyDropdown(dropdownKey1);
            FillKeyDropdown(dropdownKey2);

            if (dropdownKey1 != null)
            {
                hotkeyIndex1       = Mathf.Clamp(hotkeyIndex1, 0, KeyCodeName.KeyNames.Length - 1);
                dropdownKey1.value = hotkeyIndex1;
                dropdownKey1.RefreshShownValue();
            }

            if (dropdownKey2 != null)
            {
                hotkeyIndex2       = Mathf.Clamp(hotkeyIndex2, 0, KeyCodeName.KeyNames.Length - 1);
                dropdownKey2.value = hotkeyIndex2;
                dropdownKey2.RefreshShownValue();
            }
        }

        private static void FillKeyDropdown(Dropdown dropdown)
        {
            if (dropdown == null)
            {
                return;
            }

            dropdown.options.Clear();

            for (var i = 0; i < KeyCodeName.KeyNames.Length; i++)
            {
                dropdown.options.Add(new Dropdown.OptionData(KeyCodeName.KeyNames[i]));
            }

            dropdown.RefreshShownValue();
        }

        private void OnDropdownKey1Changed(int value)
        {
            hotkeyIndex1 = value;
            SetStatus("快捷键1：" + KeyCodeName.GetKeyNameByIndex(hotkeyIndex1));
        }

        private void OnDropdownKey2Changed(int value)
        {
            hotkeyIndex2 = value;
            SetStatus("快捷键2：" + KeyCodeName.GetKeyNameByIndex(hotkeyIndex2));
        }

        private void OnScaleChanged(float value)
        {
            uiScale = Mathf.Clamp(value, MinUiScale, MaxUiScale);
            ApplyUiScale();
        }

        private void ApplyUiScale()
        {
            if (rootPanel != null)
            {
                rootPanel.localScale = Vector3.one * uiScale;
            }

            if (textUiScale != null)
            {
                textUiScale.text = uiScale.ToString("0.00");
            }
        }

        private void TogglePanelVisible()
        {
            _panelVisible = !_panelVisible;

            if (rootPanel != null)
            {
                rootPanel.gameObject.SetActive(_panelVisible);
            }

            if (btnTogglePanel != null)
            {
                var buttonText = btnTogglePanel.GetComponentInChildren<Text>();
                if (buttonText != null)
                {
                    buttonText.text = _panelVisible ? "隐藏面板" : "显示面板";
                }
            }
        }

        private void RefreshProcessList()
        {
            _processInfos.Clear();

            var processArray = Array.Empty<Process>();

            try
            {
                processArray = Process.GetProcesses();

                for (var i = 0; i < processArray.Length; i++)
                {
                    if (!TryBuildProcessInfo(processArray[i], out var info))
                    {
                        continue;
                    }

                    _processInfos.Add(info);
                }

                _processInfos.Sort((a, b) => string.Compare(a.ProcessName, b.ProcessName, StringComparison.OrdinalIgnoreCase));
                SetStatus("进程列表已刷新：" + _processInfos.Count + " 个。");
            }
            finally
            {
                for (var i = 0; i < processArray.Length; i++)
                {
                    processArray[i].Dispose();
                }
            }

            RefreshProcessListView();
        }

        private void RefreshProcessListView()
        {
            if (processContent == null)
            {
                return;
            }

            ClearSpawnedRows();

            var visibleIndex = 0;
            for (var i = 0; i < _processInfos.Count; i++)
            {
                var info = _processInfos[i];
                if (!IsProcessVisible(info))
                {
                    continue;
                }

                visibleIndex++;
                CreateProcessRow(visibleIndex, info);
            }
        }

        private void ClearSpawnedRows()
        {
            for (var i = 0; i < _spawnedRows.Count; i++)
            {
                if (_spawnedRows[i] != null)
                {
                    Destroy(_spawnedRows[i]);
                }
            }

            _spawnedRows.Clear();
        }

        private bool IsProcessVisible(ProcessInfo info)
        {
            var onlyWindow = toggleOnlyWindow != null ? toggleOnlyWindow.isOn : true;
            if (onlyWindow && info.MainWindowHandle == IntPtr.Zero)
            {
                return false;
            }

            var keyword = inputSearch != null ? inputSearch.text : string.Empty;
            if (string.IsNullOrEmpty(keyword))
            {
                return true;
            }

            return info.ProcessName != null &&
                   info.ProcessName.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void CreateProcessRow(int order, ProcessInfo info)
        {
            var row = CreateProcessRowBase("ProcessRow_" + info.ProcessId, processContent, new Color(0.05f, 0.05f, 0.05f, 0.65f));
            _spawnedRows.Add(row.gameObject);

            CreateProcessCell(order.ToString(), row, 45, FontStyle.Normal);
            CreateProcessCell(info.ProcessId.ToString(), row, 70, FontStyle.Normal);
            CreateProcessCell(info.MainWindowHandle.ToString(), row, 130, FontStyle.Normal);
            CreateProcessCell(info.ProcessName, row, 260, FontStyle.Normal);

            var actionGroup = CreateHorizontalGroup("Actions", row, 32);
            AddLayout(actionGroup.gameObject, 0, 420, 32);

            CreateButton("Show", "显示", actionGroup, 58, 28).onClick.AddListener(() => ShowProcessWindow(info));
            CreateButton("Hide", toggleUseHide != null && toggleUseHide.isOn ? "隐藏" : "最小化", actionGroup, 70, 28).onClick.AddListener(() => HideOrMinimizeProcessWindow(info));
            CreateButton("Kill", "杀掉", actionGroup, 58, 28).onClick.AddListener(() => KillProcess(info));
            CreateButton("Copy", "复制名", actionGroup, 70, 28).onClick.AddListener(() => CopyProcessName(info));
            CreateButton("Search", "搜同名", actionGroup, 70, 28).onClick.AddListener(() =>
            {
                if (inputSearch != null)
                {
                    inputSearch.text = info.ProcessName;
                }
            });
        }

        private void ShowProcessWindow(ProcessInfo info)
        {
            if (info.MainWindowHandle == IntPtr.Zero)
            {
                SetStatus("进程没有可显示的主窗口：" + info.ProcessName);
                return;
            }

            var success = WindowAPI.RestoreAndActivateWindow(info.MainWindowHandle);
            SetStatus(success ? "已显示并激活：" + info.ProcessName : "显示失败：" + info.ProcessName);
        }

        private void HideOrMinimizeProcessWindow(ProcessInfo info)
        {
            if (info.MainWindowHandle == IntPtr.Zero)
            {
                SetStatus("进程没有可隐藏/最小化的主窗口：" + info.ProcessName);
                return;
            }

            var useHide = toggleUseHide != null && toggleUseHide.isOn;
            var success = useHide
                              ? WindowAPI.HideWindow(info.MainWindowHandle)
                              : WindowAPI.MinimizeWindow(info.MainWindowHandle);

            SetStatus(success
                          ? (useHide ? "已隐藏：" : "已最小化：") + info.ProcessName
                          : "隐藏/最小化失败：" + info.ProcessName);
        }

        private void KillProcess(ProcessInfo info)
        {
            Process process = null;
            try
            {
                process = Process.GetProcessById(info.ProcessId);
                if (process.HasExited)
                {
                    SetStatus("进程已退出：" + info.ProcessName);
                    return;
                }

                process.Kill();
                SetStatus("已杀掉进程：" + info.ProcessName + " / PID=" + info.ProcessId);
                RefreshProcessList();
            }
            catch (Exception ex)
            {
                SetStatus("杀掉进程失败：" + info.ProcessName + "，原因：" + ex.Message);
                Debug.LogWarning(ex);
            }
            finally
            {
                if (process != null)
                {
                    process.Dispose();
                }
            }
        }

        private void CopyProcessName(ProcessInfo info)
        {
            GUIUtility.systemCopyBuffer = info.ProcessName ?? string.Empty;
            SetStatus("已复制进程名：" + GUIUtility.systemCopyBuffer);
        }

        private bool TryBuildProcessInfo(Process process, out ProcessInfo processInfo)
        {
            processInfo = default(ProcessInfo);

            try
            {
                if (process == null || process.HasExited)
                {
                    return false;
                }

                process.Refresh();

                var name = process.ProcessName;
                if (string.IsNullOrEmpty(name))
                {
                    return false;
                }

                processInfo = new ProcessInfo
                {
                    ProcessId        = process.Id,
                    ProcessName      = name,
                    MainWindowHandle = process.MainWindowHandle,
                };

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void InstallKeyboardHook()
        {
            if (_windowsKeyboardHook != null)
            {
                return;
            }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
            try
            {
                _windowsKeyboardHook                 =  new KeyboardHook();
                _windowsKeyboardHook.KeyboardPressed += OnKeyPressed;
                SetStatus("键盘钩子已启动。");
            }
            catch (Exception ex)
            {
                _windowsKeyboardHook = null;
                SetStatus("键盘钩子启动失败：" + ex.Message);
                Debug.LogException(ex);
            }
#else
            SetStatus("当前平台不支持 Windows 全局键盘钩子。");
#endif
        }

        private void UninstallKeyboardHook()
        {
            if (_windowsKeyboardHook == null)
            {
                return;
            }

            _windowsKeyboardHook.KeyboardPressed -= OnKeyPressed;
            _windowsKeyboardHook.Dispose();
            _windowsKeyboardHook = null;
            _pressedKeys.Clear();
            _shortcutTriggered = false;
        }

        private void OnKeyPressed(object sender, GlobalKeyboardHookEventArgs e)
        {
            var code = e.KeyboardData.VirtualCode;

            switch (e.KeyboardState)
            {
                case KeyboardState.KeyDown:
                case KeyboardState.SysKeyDown:
                    _pressedKeys.Add(code);
                    TryTriggerShortcut();
                    break;

                case KeyboardState.KeyUp:
                case KeyboardState.SysKeyUp:
                    _pressedKeys.Remove(code);
                    ResetTriggerIfShortcutReleased();
                    break;
            }
        }

        private void TryTriggerShortcut()
        {
            if (_shortcutTriggered)
            {
                return;
            }

            var requiredKeys = GetRequiredKeys();
            if (requiredKeys.Count == 0)
            {
                return;
            }

            for (var i = 0; i < requiredKeys.Count; i++)
            {
                if (!_pressedKeys.Contains(requiredKeys[i]))
                {
                    return;
                }
            }

            _shortcutTriggered = true;
            _hotkeyTriggerCount++;
            _panelVisible = true;

            if (rootPanel != null)
            {
                rootPanel.gameObject.SetActive(true);
            }

            RefreshProcessList();
            SetStatus("快捷键触发：已显示 UGUI 面板并刷新进程列表，次数：" + _hotkeyTriggerCount);
        }

        private void ResetTriggerIfShortcutReleased()
        {
            var requiredKeys = GetRequiredKeys();
            if (requiredKeys.Count == 0)
            {
                _shortcutTriggered = false;
                return;
            }

            for (var i = 0; i < requiredKeys.Count; i++)
            {
                if (!_pressedKeys.Contains(requiredKeys[i]))
                {
                    _shortcutTriggered = false;
                    return;
                }
            }
        }

        private List<int> GetRequiredKeys()
        {
            var result = new List<int>();

            var key1 = KeyCodeName.GetKeyValueByIndex(hotkeyIndex1);
            var key2 = KeyCodeName.GetKeyValueByIndex(hotkeyIndex2);

            if (key1 > 0)
            {
                result.Add(key1);
            }

            if (key2 > 0 && key2 != key1)
            {
                result.Add(key2);
            }

            return result;
        }

        private void SetStatus(string message)
        {
            _statusText = message ?? string.Empty;

            if (statusText != null)
            {
                statusText.text = "状态：" + _statusText;
            }

            if (!string.IsNullOrEmpty(message))
            {
                Debug.Log("[快捷键切换应用-UGUI] " + message);
            }
        }

        #region UGUI Factory

        private static RectTransform CreatePanel(string name, RectTransform parent)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(parent, false);

            var image = obj.GetComponent<Image>();
            image.color = new Color(0.03f, 0.03f, 0.03f, 0.88f);

            return obj.GetComponent<RectTransform>();
        }

        private static RectTransform CreateHorizontalGroup(string namePar, RectTransform parent, float height)
        {
            var obj = new GameObject(namePar, typeof(RectTransform), typeof(HorizontalLayoutGroup));
            obj.transform.SetParent(parent, false);

            var group = obj.GetComponent<HorizontalLayoutGroup>();
            group.spacing                = 6;
            group.childAlignment         = TextAnchor.MiddleLeft;
            group.childControlWidth      = false;
            group.childControlHeight     = true;
            group.childForceExpandWidth  = false;
            group.childForceExpandHeight = false;

            AddLayout(obj, 1, -1, height);
            return obj.GetComponent<RectTransform>();
        }

        private RectTransform CreateProcessRowBase(string name, RectTransform parent, Color color)
        {
            var row   = CreateHorizontalGroup(name, parent, 34);
            var image = row.gameObject.AddComponent<Image>();
            image.color = color;

            var group = row.GetComponent<HorizontalLayoutGroup>();
            group.padding = new RectOffset(4, 4, 2, 2);

            return row;
        }

        private Text CreateProcessCell(string text, RectTransform parent, float width, FontStyle style)
        {
            var cell = CreateText("Cell", text, parent, 13, style, TextAnchor.MiddleLeft);
            AddLayout(cell.gameObject, 0, width, 30);
            return cell;
        }

        private Text CreateText(string name, string text, RectTransform parent, int fontSize, FontStyle fontStyle, TextAnchor alignment)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Text));
            obj.transform.SetParent(parent, false);

            var uiText = obj.GetComponent<Text>();
            uiText.text               = text;
            uiText.font               = _defaultFont != null ? _defaultFont : Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            uiText.fontSize           = fontSize;
            uiText.fontStyle          = fontStyle;
            uiText.alignment          = alignment;
            uiText.color              = Color.white;
            uiText.horizontalOverflow = HorizontalWrapMode.Overflow;
            uiText.verticalOverflow   = VerticalWrapMode.Truncate;

            return uiText;
        }

        private Button CreateButton(string name, string text, RectTransform parent, float width, float height)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            obj.transform.SetParent(parent, false);

            var image = obj.GetComponent<Image>();
            image.color = new Color(0.18f, 0.18f, 0.18f, 1f);

            var button = obj.GetComponent<Button>();
            var colors = button.colors;
            colors.normalColor      = new Color(0.18f, 0.18f, 0.18f, 1f);
            colors.highlightedColor = new Color(0.28f, 0.28f, 0.28f, 1f);
            colors.pressedColor     = new Color(0.12f, 0.12f, 0.12f, 1f);
            colors.selectedColor    = new Color(0.20f, 0.20f, 0.20f, 1f);
            button.colors           = colors;

            var rect = obj.GetComponent<RectTransform>();
            AddLayout(obj, 0, width, height);

            var label     = CreateText("Text", text, rect, 13, FontStyle.Normal, TextAnchor.MiddleCenter);
            var labelRect = label.GetComponent<RectTransform>();
            labelRect.anchorMin = Vector2.zero;
            labelRect.anchorMax = Vector2.one;
            labelRect.offsetMin = Vector2.zero;
            labelRect.offsetMax = Vector2.zero;

            return button;
        }

        private Toggle CreateToggle(string name, string text, RectTransform parent, float width, float height)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Toggle));
            obj.transform.SetParent(parent, false);
            AddLayout(obj, 0, width, height);

            var toggle = obj.GetComponent<Toggle>();
            toggle.isOn = false;

            var background = new GameObject("Background", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            background.SetParent(obj.transform, false);
            background.anchorMin        = new Vector2(0, 0.5f);
            background.anchorMax        = new Vector2(0, 0.5f);
            background.sizeDelta        = new Vector2(18, 18);
            background.anchoredPosition = new Vector2(9, 0);

            var backgroundImage = background.GetComponent<Image>();
            backgroundImage.color = new Color(0.15f, 0.15f, 0.15f, 1f);

            var checkmark = new GameObject("Checkmark", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            checkmark.SetParent(background, false);
            checkmark.anchorMin = Vector2.zero;
            checkmark.anchorMax = Vector2.one;
            checkmark.offsetMin = new Vector2(3, 3);
            checkmark.offsetMax = new Vector2(-3, -3);

            var checkmarkImage = checkmark.GetComponent<Image>();
            checkmarkImage.color = Color.green;

            toggle.targetGraphic = backgroundImage;
            toggle.graphic       = checkmarkImage;

            var label     = CreateText("Label", text, obj.GetComponent<RectTransform>(), 13, FontStyle.Normal, TextAnchor.MiddleLeft);
            var labelRect = label.GetComponent<RectTransform>();
            labelRect.anchorMin = new Vector2(0, 0);
            labelRect.anchorMax = new Vector2(1, 1);
            labelRect.offsetMin = new Vector2(26, 0);
            labelRect.offsetMax = Vector2.zero;

            return toggle;
        }

        private InputField CreateInputField(string name, RectTransform parent, float width, float height)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(InputField));
            obj.transform.SetParent(parent, false);
            AddLayout(obj, 0, width, height);

            var image = obj.GetComponent<Image>();
            image.color = new Color(0.10f, 0.10f, 0.10f, 1f);

            var text     = CreateText("Text", string.Empty, obj.GetComponent<RectTransform>(), 14, FontStyle.Normal, TextAnchor.MiddleLeft);
            var textRect = text.GetComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(8, 2);
            textRect.offsetMax = new Vector2(-8, -2);

            var placeholder = CreateText("Placeholder", "输入进程名搜索", obj.GetComponent<RectTransform>(), 14, FontStyle.Italic, TextAnchor.MiddleLeft);
            placeholder.color = new Color(1f, 1f, 1f, 0.35f);
            var placeholderRect = placeholder.GetComponent<RectTransform>();
            placeholderRect.anchorMin = Vector2.zero;
            placeholderRect.anchorMax = Vector2.one;
            placeholderRect.offsetMin = new Vector2(8, 2);
            placeholderRect.offsetMax = new Vector2(-8, -2);

            var input = obj.GetComponent<InputField>();
            input.textComponent = text;
            input.placeholder   = placeholder;

            return input;
        }

        private Dropdown CreateDropdown(string name, RectTransform parent, float width, float height)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Dropdown));
            obj.transform.SetParent(parent, false);
            AddLayout(obj, 0, width, height);

            var image = obj.GetComponent<Image>();
            image.color = new Color(0.10f, 0.10f, 0.10f, 1f);

            var label     = CreateText("Label", string.Empty, obj.GetComponent<RectTransform>(), 13, FontStyle.Normal, TextAnchor.MiddleLeft);
            var labelRect = label.GetComponent<RectTransform>();
            labelRect.anchorMin = Vector2.zero;
            labelRect.anchorMax = Vector2.one;
            labelRect.offsetMin = new Vector2(8, 0);
            labelRect.offsetMax = new Vector2(-24, 0);

            var arrow     = CreateText("Arrow", "▼", obj.GetComponent<RectTransform>(), 13, FontStyle.Bold, TextAnchor.MiddleCenter);
            var arrowRect = arrow.GetComponent<RectTransform>();
            arrowRect.anchorMin        = new Vector2(1, 0);
            arrowRect.anchorMax        = new Vector2(1, 1);
            arrowRect.pivot            = new Vector2(1, 0.5f);
            arrowRect.sizeDelta        = new Vector2(22, 0);
            arrowRect.anchoredPosition = Vector2.zero;

            var dropdown = obj.GetComponent<Dropdown>();
            dropdown.captionText   = label;
            dropdown.targetGraphic = image;

            // Dropdown Template
            var template = CreateDropdownTemplate(obj.GetComponent<RectTransform>(), label.font);
            dropdown.template = template;
            template.gameObject.SetActive(false);

            return dropdown;
        }

        private RectTransform CreateDropdownTemplate(RectTransform dropdownRoot, Font font)
        {
            var template = new GameObject("Template", typeof(RectTransform), typeof(Image), typeof(ScrollRect)).GetComponent<RectTransform>();
            template.SetParent(dropdownRoot, false);
            template.anchorMin        = new Vector2(0, 0);
            template.anchorMax        = new Vector2(1, 0);
            template.pivot            = new Vector2(0.5f, 1);
            template.anchoredPosition = new Vector2(0, -2);
            template.sizeDelta        = new Vector2(0, 220);

            var templateImage = template.GetComponent<Image>();
            templateImage.color = new Color(0.08f, 0.08f, 0.08f, 1f);

            var scrollRect = template.GetComponent<ScrollRect>();
            scrollRect.horizontal = false;

            var viewport = new GameObject("Viewport", typeof(RectTransform), typeof(Mask), typeof(Image)).GetComponent<RectTransform>();
            viewport.SetParent(template, false);
            viewport.anchorMin = Vector2.zero;
            viewport.anchorMax = Vector2.one;
            viewport.offsetMin = Vector2.zero;
            viewport.offsetMax = Vector2.zero;

            var mask = viewport.GetComponent<Mask>();
            mask.showMaskGraphic = false;

            var viewportImage = viewport.GetComponent<Image>();
            viewportImage.color = new Color(1f, 1f, 1f, 0.05f);

            var content = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter)).GetComponent<RectTransform>();
            content.SetParent(viewport, false);
            content.anchorMin = new Vector2(0, 1);
            content.anchorMax = new Vector2(1, 1);
            content.pivot     = new Vector2(0.5f, 1);
            content.offsetMin = Vector2.zero;
            content.offsetMax = Vector2.zero;

            var layout = content.GetComponent<VerticalLayoutGroup>();
            layout.childControlHeight     = false;
            layout.childControlWidth      = true;
            layout.childForceExpandHeight = false;
            layout.childForceExpandWidth  = true;

            var fitter = content.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            var item = new GameObject("Item", typeof(RectTransform), typeof(Toggle)).GetComponent<RectTransform>();
            item.SetParent(content, false);
            item.sizeDelta = new Vector2(0, 28);

            var toggle = item.GetComponent<Toggle>();
            toggle.isOn = false;

            var itemBackground = new GameObject("Item Background", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            itemBackground.SetParent(item, false);
            itemBackground.anchorMin = Vector2.zero;
            itemBackground.anchorMax = Vector2.one;
            itemBackground.offsetMin = Vector2.zero;
            itemBackground.offsetMax = Vector2.zero;

            var itemBackgroundImage = itemBackground.GetComponent<Image>();
            itemBackgroundImage.color = new Color(0.16f, 0.16f, 0.16f, 1f);

            var itemCheckmark = new GameObject("Item Checkmark", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            itemCheckmark.SetParent(item, false);
            itemCheckmark.anchorMin        = new Vector2(0, 0.5f);
            itemCheckmark.anchorMax        = new Vector2(0, 0.5f);
            itemCheckmark.sizeDelta        = new Vector2(18, 18);
            itemCheckmark.anchoredPosition = new Vector2(12, 0);

            var itemCheckmarkImage = itemCheckmark.GetComponent<Image>();
            itemCheckmarkImage.color = Color.green;

            var itemLabel     = CreateText("Item Label", "Option", item, 13, FontStyle.Normal, TextAnchor.MiddleLeft);
            var itemLabelRect = itemLabel.GetComponent<RectTransform>();
            itemLabelRect.anchorMin = Vector2.zero;
            itemLabelRect.anchorMax = Vector2.one;
            itemLabelRect.offsetMin = new Vector2(32, 0);
            itemLabelRect.offsetMax = new Vector2(-6, 0);

            toggle.targetGraphic = itemBackgroundImage;
            toggle.graphic       = itemCheckmarkImage;

            scrollRect.viewport = viewport;
            scrollRect.content  = content;

            // 注意：
            // UnityEngine.UI.Dropdown 没有公开的 Dropdown.Item 类型。
            // 这里不要手动 AddComponent<Dropdown.Item>()。
            // Dropdown 只需要模板中存在 Toggle、Text、Checkmark 等结构，
            // 内部会在展开时自行复制和处理模板项。
            return template;
        }

        private Slider CreateSlider(string name, RectTransform parent, float width, float height)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Slider));
            obj.transform.SetParent(parent, false);
            AddLayout(obj, 0, width, height);

            var slider = obj.GetComponent<Slider>();
            slider.direction = Slider.Direction.LeftToRight;

            var background = new GameObject("Background", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            background.SetParent(obj.transform, false);
            background.anchorMin                   = new Vector2(0, 0.35f);
            background.anchorMax                   = new Vector2(1, 0.65f);
            background.offsetMin                   = Vector2.zero;
            background.offsetMax                   = Vector2.zero;
            background.GetComponent<Image>().color = new Color(0.12f, 0.12f, 0.12f, 1f);

            var fillArea = new GameObject("Fill Area", typeof(RectTransform)).GetComponent<RectTransform>();
            fillArea.SetParent(obj.transform, false);
            fillArea.anchorMin = Vector2.zero;
            fillArea.anchorMax = Vector2.one;
            fillArea.offsetMin = new Vector2(5, 0);
            fillArea.offsetMax = new Vector2(-5, 0);

            var fill = new GameObject("Fill", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            fill.SetParent(fillArea, false);
            fill.anchorMin                   = Vector2.zero;
            fill.anchorMax                   = Vector2.one;
            fill.offsetMin                   = Vector2.zero;
            fill.offsetMax                   = Vector2.zero;
            fill.GetComponent<Image>().color = new Color(0.25f, 0.55f, 1f, 1f);

            var handleArea = new GameObject("Handle Slide Area", typeof(RectTransform)).GetComponent<RectTransform>();
            handleArea.SetParent(obj.transform, false);
            handleArea.anchorMin = Vector2.zero;
            handleArea.anchorMax = Vector2.one;
            handleArea.offsetMin = new Vector2(6, 0);
            handleArea.offsetMax = new Vector2(-6, 0);

            var handle = new GameObject("Handle", typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
            handle.SetParent(handleArea, false);
            handle.sizeDelta                   = new Vector2(16, 22);
            handle.GetComponent<Image>().color = Color.white;

            slider.fillRect      = fill;
            slider.handleRect    = handle;
            slider.targetGraphic = handle.GetComponent<Image>();

            return slider;
        }

        private static void AddLayout(GameObject obj, int flexibleWidth, float preferredWidth, float preferredHeight)
        {
            var element = obj.GetComponent<LayoutElement>();
            if (element == null)
            {
                element = obj.AddComponent<LayoutElement>();
            }

            element.flexibleWidth = flexibleWidth;
            if (preferredWidth > 0)
            {
                element.preferredWidth = preferredWidth;
            }

            if (preferredHeight > 0)
            {
                element.preferredHeight = preferredHeight;
            }
        }

        #endregion

        private struct ProcessInfo
        {
            public int ProcessId;
            public string ProcessName;
            public IntPtr MainWindowHandle;
        }
    }
}